
#' The OR.fun function
#'
#' @param x  A predictor variable.
#'
#' @param data The data to be used.
#'
#' @param option There are three options: "Quantile" - change predictor to quantiles; "ordinal" treat quantiles as ordinal; "Raw" do not change.
#'
#' @param path The folder name for write the outcome to.
#'
#' @param constant  A constant to be added to the Beta distribution to reflect the appropriate prior. For example, constant=1 reflects uniform (0,1), and constant=0.5 reflects Jeffery's prior.
#'
#' @examples
#'
#' # This is the function for doing logistic regression.
#'
#' @export


##############################
# The logistic regression analysis for a binary outcome

Reg.fun=function(data, x, option, y, path)
{data=as.data.frame(data)
data$x=data[,x]; data$y=as.numeric(data[,y])
data$quantiles <- cut(data$x, breaks = quantile(data$x, probs = seq(0, 1, 0.25), na.rm=TRUE), include.lowest = TRUE, labels = c("QQ1", "QQ2", "QQ3", "QQ4"))
data$ocat <- cut(data$x, breaks = quantile(data$x, probs = seq(0, 1, 0.25), na.rm=TRUE), include.lowest = TRUE, labels = c(1,2,3,4))
data$ocat=as.numeric(data$ocat)

##############################################################################
if (option%in%c("Quantile", "quantile"))

{ mdl= (glm((data$y)~data$quantiles+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1))
smdl=round(summary(mdl)$coefficients,3)
CI=paste0("(", round(confint(mdl)[,1], 3), ", ", round(confint(mdl)[,2], 3), ")", sep="")
out=cbind(smdl[,c(1,2)], CI, smdl[,3:4])
out=as.data.frame(out[,c(1,2,3,5)])
out=out[-(row.names(out)=="(Intercept)"),]
rmv=gregexpr("$", row.names(out)[1], fixed = TRUE)[[1]][1]
row.names(out)=substr(row.names(out), rmv+1, 300)
out=out[substr(row.names(out),1,7)=="quantil",]
names(out)[3:4]=c("95 CI", "p")
out=out[,-2]

cout=cbind(x=row.names(out), out)
names(cout)[1]=x

write.csv(cout , paste(path, "Quantile.", x,".raw.", y,".csv", sep=""), row.names=FALSE)}

##############################################################################
if (option%in%c("Ordinal", "ordinal"))

{data$x=data$ocat
mdl= (glm((data$y)~data$x+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1))
smdl=round(summary(mdl)$coefficients,3)
CI=paste0("(", round(confint(mdl)[,1], 3), ", ", round(confint(mdl)[,2], 3), ")", sep="")
out=cbind(smdl[,c(1,2)], CI, smdl[,3:4])
out=as.data.frame(out[,c(1,2,3,5)])
out=out[-(row.names(out)=="(Intercept)"),]
rmv=gregexpr("$", row.names(out)[1], fixed = TRUE)[[1]][1]
row.names(out)=substr(row.names(out), rmv+1, 300)
out=out[row.names(out)=="x",]
names(out)[3:4]=c("95 CI", "p")
out=out[,-2]

cout=cbind(x="Trend", out)
names(cout)[1]=x

write.csv(cout , paste(path, "Ordinal.", x,".raw.", y,".csv", sep=""), row.names=FALSE)}

##############################################################################
if (option%in%c("Raw", "raw"))

{ mdl= (glm((data$y)~data$x+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1))
smdl=round(summary(mdl)$coefficients,3)
CI=paste0("(", round(confint(mdl)[,1], 3), ", ", round(confint(mdl)[,2], 3), ")", sep="")
out=cbind(smdl[,c(1,2)], CI, smdl[,3:4])
out=as.data.frame(out[,c(1,2,3,5)])
out=out[-(row.names(out)=="(Intercept)"),]
rmv=gregexpr("$", row.names(out)[1], fixed = TRUE)[[1]][1]
row.names(out)=substr(row.names(out), rmv+1, 300)
out=out[row.names(out)=="x",]
names(out)[3:4]=c("95 CI", "p")
out=out[,-2]

cout=cbind(x="Continuous", out)
names(cout)[1]=x

write.csv(cout , paste(path, "Continuous.", x,".raw.", y,".csv", sep=""), row.names=FALSE)}


return(cout)
}
