
library("survival")
library("survminer")

Spline.cox.fun=function(file.name, index, data.path, out.path, plot.path)
{data=read.table(paste0(data.path, file.name),header=TRUE, sep="\t")
symps=c("nausea","vomit","diarrhea","shortbreath","handfoot","numb","pain","muscache","fatigue")

for (j in 1:length(symps))
{ if (sum(data[,symps[j]]>0)<10) {} else
{ tiff(paste0(plot.path, index, "-", symps[j], ".spline.cox.tif"), width = 2000, heigh=1800, res=600,
       compression = 'zip', pointsize = 10)

data$status=data[,symps[j]]/3
data$time=data[,paste0(symps[j], ".t")]
#data$AHEI12=data$AHEI1>median(data$AHEI1)

#KM <- survfit(Surv(time, status) ~ AHEI12, data=data)
#plot(KM, ylab="Severe symptom free Probability", xlab="Day", col=1:2, lwd=2, main=symps[j], ylim=c(.40,1))
#legend(0,.60, c("Low baseline AHEI", "High baseline AHEI"), col=1:2, lwd=2)

df=3
dataw=data
dataw=dataw[!is.na(dataw[,index]),]
sm0 <-coxph( as.formula( paste0("Surv(time, status) ~ pspline(", index, ", df=df)" ))  , data = dataw)
sm <-coxph( as.formula( paste0("Surv(time, status) ~ pspline(", index, ", df=df)+DT_KCAL1+Age_rand +as.factor(rand_tx_duration)+as.factor(race_ethnicity)+as.factor(intervention)" ))  , data = dataw)

smm0=summary(sm0)[[7]]
smm=summary(sm)[[7]]

sout0=cbind(c(symps[j], ""), c("Linear", "non-linear"), paste0(round(exp(smm0[,1]), 3), "(", round(exp(smm0[,1]-smm0[,2]*1.96),3), ", ", round(exp(smm0[,1]+smm0[,2]*1.96),3), ")"), round(smm0[,6],3),
            paste0(round(exp(smm[1:2,1]), 3), "(", round(exp(smm[1:2,1]-smm[1:2,2]*1.96),3), ", ", round(exp(smm[1:2,1]+smm[1:2,2]*1.96),3), ")"), round(smm[1:2,6],3) )


sout0[2,sout0[2,]=="NA(NA, NA)"]=""

if (j==1) {out=sout0} else {out=rbind(out, sout0)}

 linear.p=round(summary(sm)$coefficients[,6][1],3)

 nonlinear.p=round(summary(sm)$coefficients[,6][2],3)

 ptemp=termplot(sm, se=TRUE, plot=FALSE)

 xxyy=ptemp[[1]]

yyy <- xxyy$y + outer(xxyy$se, c(0, -1.96, 1.96), '*')
plot(xxyy$x, xxyy$y, pch=16, lty=1, lwd=2, type="l", ylim=c(-1.5,3.3))
plot(xxyy$x, xxyy$y, pch=16, lty=1, lwd=2, type="l", ylim=c(min(yyy),max(yyy)),
     xlab=paste0(index, " at baseline"), ylab="Hazard ratio", main=symps[j])

 points(xxyy$x, yyy[,1], type="l", col=4, lwd=3)
 points(xxyy$x, yyy[,2], type="l", col=4, lwd=3, lty=3)
 points(xxyy$x, yyy[,3], type="l", col=4, lwd=3, lty=3)

 text(min(xxyy$x)+.2*diff(c(min(xxyy$x),max(xxyy$x))  ), min(yyy)+.1*diff(c(min(yyy),max(yyy))  ), paste0("linear p:", linear.p), cex=.7)
 text(min(xxyy$x)+.2*diff(c(min(xxyy$x),max(xxyy$x))  ), min(yyy)+.01*diff(c(min(yyy),max(yyy))  ), paste0("nonlinear p:", nonlinear.p), cex=.7)

 dev.off()
}
}

out=as.data.frame(out)
 names(out)=c("Symptom", "term", "Raw HR", "Raw P", "Adjusted HR", "Adjusted p")

write.csv(out, paste0(out.path, index, "-symptom.Table.csv"), row.names = FALSE)

 }





