

Bcr.0 = function(T,kluster,inc,pvar,pii,sdd,pBeta, Beta, x, y, n.n, p.crit, p.conf)
{

library(HardyWeinberg)

   pii0=pii
   for (i in 1:30)
      {
       for (j in 1:kluster)
           {if (i!=1&j==2) {sdd[j]=sdd[j]/sqrt(2)}
            T[,j]=pii[j]*(dnorm((y-as.matrix(x)%*%as.matrix(Beta[,j])),0,sdd[j]))
           }

       T[rowSums(T)!=0,]=T[rowSums(T)!=0,]/rowSums(T[rowSums(T)!=0,])
       pii=colSums(T)/n.n
       if (sum(pii-pii0)==0 &i>3) {break}

       pii0=pii
       for (j in kluster:1)
           {
            for (w in 1:n.n) {inc[w]=T[w,j]==max(T[w,])}

            if (sum(inc)==1)
               {Beta[,j]=pBeta[,j]} else
               {Beta[,j]= solve((pvar)+as.matrix(t(x[inc,])) %*% as.matrix(x[inc,]))%*%((pvar)%*%pBeta[,j]   + as.matrix(t(x[inc,])) %*% as.matrix(y[inc]))
               }
            if (any(Beta[2,]<.5))
               {Beta=pBeta
                pvar[2,2]=10*pvar[2,2]
               }
           }

       for (j in kluster:1)
           {
            for (w in 1:n.n) {inc[w]=T[w,j]==max(T[w,])}

            if (sum(inc)==1)
               {sdd[j]=0.0001} else
               {sdd[j]= apply((y[inc]-as.matrix((x[inc,]))%*%Beta[,j]), 2, sd)
               }
           }
            sdd=rep(mean(sdd[!is.na(sdd)&sdd!=0]), kluster)
       }

   T.max=ccol=rep(NA,n.n)

   for (w in 1:n.n)
       {
        ccol[w]=(which(T[w,]==max(T[w,])))+1
        T.max[w]=max(T[w,])
       }

   ccol.1=ccol

      if (length(table(ccol))==1)
      {
       if (median(x[,2]-y)>0) {ccol=0*ccol+2} else
          {ccol=0*ccol+4}
      }

   if (all(ccol.1==ccol)) {ccol[T.max<p.conf]=1}

   B.return=list(ccol,Beta)
   names(B.return)=c("col","Beta")

   return(B.return)
}


Bcr.y = function(state, tgt, cgt,M_A, M_B, nsnp, n.n, p.crit,p.conf)
{
    if (missing(p.crit)) {p.crit=.975}
    if (missing(p.conf)) {p.conf=-1}
    kluster=3

    x=cbind(1,as.vector(t(M_A[nsnp,])))
    y=as.vector(t(M_B[nsnp,]))
    cgti=as.vector(t(cgt[nsnp,]))
    cgti[cgti==2]=5
    cgti[cgti==4]=2
    cgti[cgti==5]=4

    tgti=as.vector(t(tgt[nsnp,]))
    tgti[tgti==2]=5
    tgti[tgti==4]=2
    tgti[tgti==5]=4

    y=y-mean(x[,2])
    x[,2]=x[,2]-mean(x[,2])
    inc=rep(NA,n.n)
    x[,2]=asinh(.5*x[,2])
    y=asinh(.5*y)

    CN=t(state[nsnp,])
    {q.6=abs(diff(quantile(x[,2]-y, c(.025, .975))))/2}
    {q.7=max(abs(quantile(x[,2]-y, c(.025, .975)))) *.99}

    ga=sqrt(q.6)/2

    CN[CN== 1 & (x[,2]>y)]=-ga/2/5
    CN[CN== 1 & (x[,2]<y)]= ga/2/5
    CN[CN==-1 & (x[,2]>y)]= ga
    CN[CN==-1 & (x[,2]<y)]=-ga

    x=cbind(x,CN)

    pBeta0=pBeta=Beta=cbind(c(-1,1,1), c(0,1,1),c(1,1,1))
    {Beta[1,]=pBeta0[1,]*q.7*1.0}

    T=matrix(rep(NA,n.n*kluster),ncol=kluster)
    sdd=rep(1,kluster)
    pii=rep(1/kluster,kluster)
    pii0=pii*999
    pvar=matrix(c(3,0,0, 0, 3, 0, 0, 0, .2),3)

    ccol.0=Bcr.0(T,kluster, inc, pvar, pii, sdd, pBeta, Beta, x, y, n.n, p.crit=.975, p.conf=p.conf)
    ccol.01=ccol.0[[1]]
    ccol=ccol.0[[1]]
    outtt=ccol-1

    scol=t(state[nsnp,])
    cCN=is.na(scol)
    cCN[scol==0]=8
    cCN[scol==-1]=2
    cCN[scol== 1]=3
    spch=is.na(scol)
    spch[scol==0]=16
    spch[scol==-1]=13
    spch[scol==1]=12

    outlist=list(x[,2], y, outtt)
    names(outlist)=c("x", "y", "gt")
    return(outlist)
}


BCRgt = function (data.for.A, data.for.B, state.data, p.conf, nrows)

{
   if (missing(nrows)) {nrows=99999999999999999999}
   if (missing(p.conf)) {p.conf=-1}

   M_A=read.table(data.for.A, header=TRUE, sep="\t", nrows=nrows)
   M_B=read.table(data.for.B, header=TRUE, sep="\t", nrows=nrows)
   state=read.table(state.data, header=TRUE, sep="\t", nrows=nrows)

   size=1:dim(M_A)[[2]]
   x0=M_A[,size]
   y0=M_B[,size]
   n.n=dim(x0)[[2]]

   for (nsnp in 1:dim(x0)[[1]])
       {oou=Bcr.y(state, tgt, cgt, x0, y0, nsnp, n.n, p.conf=p.conf)

        if (nsnp==1)
           {GT2=(oou[[3]])} else
           {GT2=cbind(GT2, oou[[3]])
           }
       }

   GT2=t(GT2)
   names(GT2[1,])=names(M_A)

   return (GT2)
}

