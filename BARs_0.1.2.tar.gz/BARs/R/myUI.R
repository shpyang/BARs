#' The postP.Bfun function
#'
#' @import stats
#'
#' @import utils
#'
#' @import readxl
#'
#' @importFrom shiny observeEvent
#'
#' @importFrom shiny reactiveVal
#'
#' @importFrom shiny titlePanel
#'
#' @importFrom shiny validate
#'
#' @importFrom shiny sidebarLayout
#'
#' @importFrom shiny sidebarPanel
#'
#' @importFrom shiny uiOutput
#'
#' @importFrom shiny column
#'
#' @importFrom shiny sidebarLayout
#'
#' @importFrom shiny renderUI
#'
#' @importFrom shiny h3
#'
#' @importFrom shiny h4
#'
#' @importFrom shiny fluidPage
#'
#' @importFrom shiny fileInput
#'
#' @importFrom shiny checkboxInput
#'
#' @importFrom shiny selectInput
#'
#' @importFrom shiny numericInput
#'
#' @importFrom shiny mainPanel
#'
#' @importFrom shiny actionButton
#'
#' @importFrom shiny br
#'
#' @importFrom shiny HTML
#'
#' @importFrom shiny div
#'
#' @importFrom shiny br
#'
#' @importFrom shiny br
#'
#' @importFrom shiny downloadHandler
#'
#' @importFrom shiny textOutput
#'
#' @importFrom shiny downloadButton
#'
#' @import DT
#
#' @import redcapAPI
#'
#' @import REDCapR
#'
#' @examples
#'
#' myUI()
#'
#' @export

myUI= function()
{  fluidPage(
  div(style = "background-color: white; color: brown;",titlePanel("Bayesian Covariate-Adaptive Randomization (BayCAR)!")),
  sidebarLayout(
    # Sidebar with a slider input
    sidebarPanel
    ( column(12,
                   h4("Two options for data input. Please choose one."
                      , style = "background-color: white; font-size: 25px; color: red;")),
      column(12,
             h4("Option 1: Upload an Excel table."
                , style = "background-color: white; font-size: 25px; color: blue;")),
      column(12, fileInput("file2",  ("New subject file in .xlsx format"), accept = ".xlsx"),
     #        checkboxInput("header2", "Header", TRUE)
             ),

#      column(6, selectInput("arms", "Treatment Arms",
#                            c("2 arms", "3 arms", "4 arms", "5 arms", "6 arms", "7 arms", "8 arms", "9 arms"),selected ="5 arms")),
#      column(6, selectInput("trial", "Trial type",
#                            c("multi-site", "single-site"),selected ="multi-site")),
#      column(6, numericInput("planned.sample.size", "planned.sample.size", 20)),
#      column(12, selectInput("Continuous", "Continuous covariates",
#                             choices = c("age", "NA", "sex"),selected = "NA", selectize = TRUE, multiple = TRUE))
      column(12,
             h4(" "
                , style = "background-color: white; font-size: 25px; color: green;")),
      column(12,
             h4(" "
                , style = "background-color: white; font-size: 25px; color: green;")),
      column(12,
             h4("Option 2: Input manually."
                , style = "background-color: white; font-size: 25px; color: blue;")),
      column(6, textInput("record_id", "Subject ID", "")),
#      column(6, selectInput("trial", "Trial type",
#                            c("multi-site", "single-site"),selected ="multi-site")),
      column(6, selectInput("site", "Which site?",
                            c("PBRC (1)", "KP (2)", "DFCI (3)", ""),selected ="")),
      column(6, numericInput("age", "Age", 100, min = 18, max = 100)),
      column(6, selectInput("sex", "Gender",
                            c("Male (1)", "Female (0)", ""),selected ="")),
#      column(6, selectInput("age2", ">60 years old?",
#                            c(">60 (1)", "<=60 (0)", ""),selected ="")),
      column(6, selectInput("duration", "Duration of chemotherapy",
                            c("3 months (0)", "6 months (1)", ""),selected ="")),
      column(6, selectInput("oxaliplatin", "Oxaliplatin?",
                            c("Yes (1)", "No (0)", ""),selected ="")),
      column(6, selectInput("stage", "Cancer stage?",
                            c("Stage II (0)", "Stage III (1)", ""),selected ="")),
      column(6, selectInput("chemo", "Chemotherapy already started?",
                            c("Yes (1)", "No (0)", ""),selected ="")),

      column(12,
             h4(" "
                , style = "background-color: white; font-size: 50px; color: green;")),
      column(12,
             h4(" "
                , style = "background-color: white; font-size: 50px; color: green;")),
      column(12,
             h4(" "
                , style = "background-color: white; font-size: 50px; color: green;")),
      column(12,
             h3("If there are subjects to be excluded, then upload the excluded subject file."
                , style = "background-color: white; font-size: 15px; color: brown;")),
      column(12, fileInput("excludedid",  ("Excluded subject file in .xlsx format"), accept = ".xlsx"),
             #       checkboxInput("header3", "Header", TRUE)
      ),

    ),
    # main panel
    mainPanel(
      column(12,
             h4("Click the 'Show' button to confirm the input values for the new data.
                \n Do not click the 'Action' button unless all the values have been confirmed."),
             actionButton("show", "Show", style = "background-color: orange; font-size: 25px; color: blue;")),
      column(12, dataTableOutput("tablenew")),
      column(12, h3(uiOutput("noID1"))),
      column(12, h3(uiOutput("needcov"))),
      column(12, h3(uiOutput("noID2"))),
      column(12, h3(uiOutput("noID3"))),
      column(12, h3(uiOutput("wrong.ran"))),
      column(12, h3(uiOutput("notnewID"))),
      column(12, h3(uiOutput("missing.ran"))),

      column(12, div(style = "background-color: lightgray; color: darkblue;", selectInput("display", "Display diagnostic tables?", c("No", "Yes"), selected ="No", width="100%",
                        selectize = TRUE))),
      column(12, h4("Click on the 'Action' button to run! The group assignments for the new subject(s) will be shown in a table with a green background (underneath the optional blue diagnosis tables) below. Othersise, there will be a warning message in red. Also, make sure to click on the download icon to backup."),
             actionButton("action", "Action", style = "background-color: green; font-size: 30px; color: white;")),

      column(12, dataTableOutput("table1")),
      column(12, h3(uiOutput("noID5"))),

      column(6, align="center", dataTableOutput("table2")),
      column(6, align="center", dataTableOutput("table3")),
      column(6, align="center", dataTableOutput("table4")),
      column(6, align="center", dataTableOutput("table5")),
      column(6, align="center", dataTableOutput("table6")),
      column(6, align="center", dataTableOutput("table7")),
      column(6, align="center", dataTableOutput("table8")),
      column(6, align="center", dataTableOutput("table9")),
      column(6, align="center", dataTableOutput("table10")),
      column(6, align="center", dataTableOutput("table11")),
      column(6, align="center", dataTableOutput("table12")),
      column(6, align="center", dataTableOutput("table13")),
      column(6, align="center", dataTableOutput("table14")),
      column(6, align="center", dataTableOutput("table15")),
      column(6, align="center", dataTableOutput("table16")),
      column(6, align="center", dataTableOutput("table17")),
      column(6, align="center", dataTableOutput("table18")),
      column(6, align="center", dataTableOutput("table19")),
      column(6, align="center", dataTableOutput("table20")),
      column(12, align="center", dataTableOutput("table99")),
      column(12, textOutput("display" )),
      column(12, h3(textOutput(" "))),
      column(12, h3(uiOutput("WNOnewlyRandomized"))),
      br(),
      column(12, align="center", dataTableOutput("table98")),
      downloadButton("downloadData", "Download randomization data for the new subject(s)", style = "background-color: purple; font-size: 15px; color: white;"),
      downloadButton("downloadDataC", "Download randomization data for ALL subjects", style = "background-color: brown; font-size: 15px; color: white;"),

    )
  )
)
}
