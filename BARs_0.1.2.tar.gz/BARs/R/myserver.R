#' The postP.Bfun function
#'
#' @param input  The list of input variables.
#'
#' @param output  The list of output variables.
#'
#' @examples
#'
#' myserver(input, output)
#'
#' @export


myserver = function(input, output) {
  # Define a reactive value to hold the data
  data <- reactiveVal(NULL)

  observeEvent(input$show, {

    arms = "5 arms"
    trial = "multi-site"
    planned.sample.size=60
    Continuous = NA
    covariates = c("site", "sex", "age2", "duration", "oxaliplatin", "stage", "chemo")
    covariates2 = c("site", "sex", "age2", "duration", "oxaliplatin", "stage", "chemo", "age")

    IDID="record_id"
    groupletterID=LETTERS
    groupletterID=as.character(1:26)
    groupID="randomization_group"
    fields <- c(IDID, covariates, groupID)
    eventcol="redcap_event_name"
    events='ppt_arm_3'
    events2='b_arm_3'

    site=sex=age2=age=duration=oxaliplatin=stage=chemo=NA
    record_id=input$record_id

    if (input$site=="PBRC (1)") {site=1}
    if (input$site=="KP (2)") {site=2}
    if (input$site=="DFCI (3)") {site=3}

    if (input$sex=="Male (1)") {sex=1}
    if (input$sex=="Female (0)") {sex=0}

    if (length(input$age)>0)
      {if (input$age>60) {age2=1}
      if (input$age<=60) {age2=0}
    }

    print(input$age); print(age2)

    if (input$duration=="3 months (0)") {duration=0}
    if (input$duration=="6 months (1)") {duration=1}

    if (input$oxaliplatin=="No (0)") {oxaliplatin=0}
    if (input$oxaliplatin=="Yes (1)") {oxaliplatin=1}

    if (input$stage=="Stage II (0)") {stage=0}
    if (input$stage=="Stage III (1)") {stage=1}

    if (input$chemo=="No (0)") {chemo=0}
    if (input$chemo=="Yes (1)") {chemo=1}

    Rdata=rbind(data.frame(record_id=19, site=1, sex=2, age2=2, duration=1,oxaliplatin=1, stage=2, chemo=1, randomization_group=NA, redcap_event_name="ppt_sf-1"),
    data.frame(record_id=19, site=1, sex=2, age2=2, duration=1,oxaliplatin=1, stage=2, chemo=1, randomization_group=2, redcap_event_name="b-sdaf"),
    data.frame(record_id=20, site=1, sex=2, age2=2, duration=1,oxaliplatin=1, stage=2, chemo=1, randomization_group=NA, redcap_event_name="ppt_sf-1"),
    data.frame(record_id=10, site="", sex=2, age2=2, duration=1,oxaliplatin=1, stage=2, chemo=1, randomization_group=NA, redcap_event_name="ppt_sf-1"),
    data.frame(record_id=11, site="", sex=2, age2=2, duration=1,oxaliplatin=1, stage=2, chemo=1, randomization_group=NA, redcap_event_name="ppt_sf-1")
    )
    Rdata[,IDID]=as.character(Rdata[,IDID])
    Rdata[,groupID]=as.character(Rdata[,groupID])
print(Rdata)
    newdata=data.frame(record_id=record_id, site=site, sex=sex, age2=age2, duration=duration,oxaliplatin=oxaliplatin, stage=stage, chemo=chemo, randomization_group=NA)
    #newdata=read_excel("H:/WFH/pak/data/Action11.xlsx")


        # Read data from the project
    dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=fields)



    dataR$data=Rdata



    names(dataR$data)=tolower(names(dataR$data))
    data0=dataR$data[substr(dataR$data[,eventcol],1,3)=="ppt",]
    data0=data0[!is.na(data0[, IDID]),]
    data0=data0[!duplicated(data0[, IDID]),]
    data1=dataR$data[substr(dataR$data[,eventcol],1,1)=="b",]
    if (nrow(data1)>0)
    {data0=data0[,c(IDID, eventcol, covariates)]
    data1=data1[,c(IDID,groupID)]
    data1=data1[data1[, IDID]%in%data0[, IDID],]} else
    {data1=data.frame(record_id=NA, randomization_group=NA)}


   if (all(data0[, IDID]%in%data1[, IDID])) {} else
    {ndata1=data.frame(record_id=data0[, IDID][!data0[, IDID]%in%data1[, IDID]], randomization_group=NA)
    data1=rbind(data1, ndata1)
    data1=data1[!is.na(data1[,IDID]),]}

    datam=merge(data0, data1, by=IDID)
    datam[,IDID]=as.character(datam[,IDID])
   if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names  = TRUE))
    names(ex)=IDID

    eids=ex[,IDID]}
    datam0=datam=datam[!datam[,IDID]%in%eids,]
    duplicates=duplicated(datam0[,IDID])

    output$noID3=shiny::renderText("")
    if (any(duplicates)) {
      output$noID3=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! There are duplicated IDs (eg. ", paste(t(datam0[,IDID][duplicates])[1],sep=","), ") in the existing REDCap database. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!")) )) )
    }

    if (length(input$file2$datapath)==0) {new=newdata} else
    {
      file2 <- input$file2
      ext2 <- tools::file_ext(file2$datapath)
      req(file2)
      validate(need(ext2 == "xlsx", "Please upload a .xlsx file"))

      new=  read_excel(file2$datapath, col_names  = TRUE)
      names(new)=tolower(names(new))
      new=data.frame(new)
      new=new[!is.na(new[,IDID]),]

      new$site[new$site%in%c("PBRC (1)", "PBRC", "1", 1)]=1
      new$site[new$site%in%c("KP (2)", "KP", "2", 2)]=2
      new$site[new$site%in%c("DFCI (3)", "DFCI", "3", 3)]=3

      new$sex[new$sex%in%c("Male (1)", "Male", "1", 1)]=1
      new$sex[new$sex%in%c("Female (0)", "Female", "0", 0)]=0

      new$age2=NA
      new$age2[new$age>60]=1
      new$age2[new$age<=60]=0

      new$duration[new$duration%in%c("3 months (0)", "3 months", "0", 0)]=0
      new$duration[new$duration%in%c("6 months (1)", "6 months", "1", 1)]=1

      new$oxaliplatin[new$oxaliplatin%in%c("No (0)", "No", "0", 0)]=0
      new$oxaliplatin[new$oxaliplatin%in%c("Yes (1)", "Yes", "1", 1)]=1

      new$stage[new$stage%in%c("Stage II (0)", "Stage II", "0", 0)]=0
      new$stage[new$stage%in%c("Stage III (1)", "Stage III", "1", 1)]=1

      new$chemo[new$chemo%in%c("No (0)", "No", "0", 0)]=0
      new$chemo[new$chemo%in%c("Yes (1)", "Yes", "1", 1)]=1
    }

 #    new=new[!is.na(new[,IDID])]
    if (any(names(new)==groupID)) {} else
    {new$randomization_group=NA}
    if (any(names(datam)==groupID)) {} else
    {if (nrow(datam)>0) {datam$randomization_group=NA}}
    new=new[,c(IDID, covariates, groupID)]
    new[,IDID]=as.character(new[,IDID])

    eventcol.char=nchar(events)
    siteid=new$site
    siteid[siteid=="PBRC"]=1
    siteid[siteid=="KP"]=2
    siteid[siteid=="DFCI"]=3

    new[,eventcol]=paste0(substr(events,1, (eventcol.char-1)), siteid)
    datam=datam[,c(IDID,eventcol, covariates, groupID)]
    datam[,IDID]=as.character(datam[,IDID])
    datam[,groupID][is.na(datam[,groupID])]=""

    should.be.randomized=wrandomized=rep(NA, nrow(datam))
    output$missing.ran=shiny::renderUI("")

    for (i in 1:nrow(datam))
    {should.be.randomized[i]=(all(!is.na(datam[i,covariates]))&(all(datam[i, covariates]!=""))&(datam[i,groupID]==""))
    }
    if (any(should.be.randomized)) {
      srtext=datam[should.be.randomized,IDID][1]
      output$missing.ran=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Some subjects (eg. ",  srtext, ") have covariate data, but not been randomized. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!")) )) )}

    output$wrong.ran=shiny::renderUI("")

    for (i in 1:nrow(datam))
    {wrandomized[i]=any(is.na(datam[i,covariates]))&(datam[i,groupID]!="")
    }
    wdatam=datam[wrandomized,]
    if (nrow(wdatam)>0) {
      output$wrong.ran=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Some subjects (eg. ", paste(wdatam[1,IDID], sep=","), "), have missing covariate data, but been randomized. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!")) )) )}


    datam=datam[datam[,groupID]!="",]


    output$notnewID=shiny::renderText("")
    notnew=any(new[,IDID]%in%datam[,IDID])
    if (notnew) {notnID=new[new[,IDID]%in%datam[,IDID],IDID]
    output$notnewID=shiny::renderUI( HTML(as.character(div(style="color: red;",
                                                           paste0("Warning! Some subjects (eg. ", notnID[1],
                                                                  "), have already been randomized before. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!")) ) ))}

    { output$noID=shiny::renderText("                                           ")
      output$tablenew <- DT::renderDataTable(new[, -which(names(new)%in%c(eventcol, groupID))],
                                             options = list(dom = 't',bFilter=0,
                                                            autoWidth = TRUE,  columnDefs = list(list(orderable=FALSE,targets='_all', className = 'dt-center', visible=TRUE, width='100') ),
                                                            buttons = list(
                                                              list(extend = 'copy', title = "New data")),pageLength = 15, lengthChange = FALSE)
      )
    }

    output$noID1=shiny::renderText("")
    if (any(new[, IDID]=="")) {
      output$noID1=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Please input ID for this(these) subjects!"))) ) )
    }

    output$needcov=shiny::renderText("")
    if (any(is.na(new[, covariates]))) {
      output$needcov=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Please input all covriates data!"))) ) )
    }
    output$noID2=shiny::renderText("")
    if (any(!new[, IDID]%in%datam0[, IDID])) { newIDID=new[,IDID]
    output$noID2=shiny::renderUI( HTML(as.character(div(style="color: red;", paste0("Warning! Some of new subject IDs (eg. ", paste(newIDID[!newIDID%in%datam0[,IDID]][1]), ") does not exist in the pre-screening ID list. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!", sep=" "))) ) )
    }

    output$noID4=shiny::renderText("")
    if (any(is.na(datam[,covariates]))) {
      output$noID4=shiny::renderUI( HTML(as.character(div(style="color: red;", "Warning! Some of the randomized subjects have missing covariate values. Please confirm the data, close all the pop-up windows and duble click on the RUN icon again!")) ) )
    }


    output$spce=shiny::renderText("")
  }
  )

  ##############################################################################
  observeEvent(input$action, {

    arms = "5 arms"
    trial = "multi-site"
    planned.sample.size=60
    Continuous = NA
    covariates = c("site", "sex", "age2", "duration", "oxaliplatin", "stage", "chemo")

    IDID="record_id"
    groupletterID=LETTERS
    groupletterID=as.character(1:26)
    groupID="randomization_group"
    fields <- c(IDID, covariates, groupID)
    eventcol="redcap_event_name"
    events='ppt_arm_3'
    events2='b_arm_3'

    site=sex=age2=duration=oxaliplatin=stage=chemo=NA
    record_id=input$record_id

    if (input$site=="PBRC (1)") {site=1}
    if (input$site=="KP (2)") {site=2}
    if (input$site=="DFCI (3)") {site=3}

    if (input$sex=="Male (1)") {sex=1}
    if (input$sex=="Female (0)") {sex=0}

    if (length(input$age)>0)
    {if (input$age>60) {age2=1}
     if (input$age<=60) {age2=0}
    }

    if (input$duration=="3 months (0)") {duration=0}
    if (input$duration=="6 months (1)") {duration=1}

    if (input$oxaliplatin=="No (0)") {oxaliplatin=0}
    if (input$oxaliplatin=="Yes (1)") {oxaliplatin=1}

    if (input$stage=="Stage II (0)") {stage=0}
    if (input$stage=="Stage III (1)") {stage=1}

    if (input$chemo=="No (0)") {chemo=0}
    if (input$chemo=="Yes (1)") {chemo=1}

    newdata=data.frame(record_id=record_id, site=site, sex=sex, age2=age2, duration=duration,oxaliplatin=oxaliplatin, stage=stage, chemo=chemo, randomization_group=NA)

    Rdata=rbind(data.frame(record_id=19, site=2, sex=1, age2=1, duration=1,oxaliplatin=1, stage=0, chemo=1, randomization_group=NA, redcap_event_name="ppt_arm_2"),
                data.frame(record_id=19, site=2, sex=1, age2=1, duration=1,oxaliplatin=1, stage=0, chemo=1, randomization_group=2, redcap_event_name="b_arm_2"),
                data.frame(record_id=20, site=2, sex=1, age2=0, duration=1,oxaliplatin=1, stage=1, chemo=1, randomization_group=NA, redcap_event_name="ppt_arm_2"),
                data.frame(record_id=10, site="", sex=0, age2=0, duration=1,oxaliplatin=1, stage=1, chemo=1, randomization_group=NA, redcap_event_name="ppt_arm_1"),
                data.frame(record_id=11, site="", sex=0, age2=0, duration=1,oxaliplatin=1, stage=0, chemo=1, randomization_group=NA, redcap_event_name="ppt_arm_1")
    )

    #    newdata=read_excel("H:/WFH/pak/data/Action11.xlsx")

    # Read data from the project
    dataR <- redcap_read(batch_size=300, redcap_uri=api_url, token=api_token, fields=c(eventcol, fields))


    dataR$data=Rdata

    names(dataR$data)=tolower(names(dataR$data))
    data0=dataR$data[substr(dataR$data[,eventcol],1,3)=="ppt", -which(names(dataR$data)==groupID)]
    data0=data0[!is.na(data0[, IDID]),]
    data0=data0[!duplicated(data0[, IDID]),]
    data1=dataR$data[substr(dataR$data[,eventcol],1,1)=="b",]
    if (nrow(data1)>0)
    {data0=data0[,c(IDID, eventcol, covariates)]
    data1=data1[,c(IDID,groupID)]
    data1=data1[data1[, IDID]%in%data0[, IDID],]} else
    {data1=data.frame(record_id=NA, randomization_group=NA)}

    if (all(data0[, IDID]%in%data1[, IDID])) {} else
    {ndata1=data.frame(record_id=data0[, IDID][!data0[, IDID]%in%data1[, IDID]], randomization_group=NA)
    data1=rbind(data1, ndata1)
    data1=data1[!is.na(data1[,IDID]),]}

    datam=merge(data0, data1, by=IDID)
    datam[,IDID]=as.character(datam[,IDID])

    if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names  = TRUE))
    names(ex)=IDID
    eids=ex[,IDID]}

    datam0=datam=datam[!datam[,IDID]%in%eids,]
    duplicates=duplicated(datam0[,IDID])

    if (length(input$file2$datapath)==0) {new=newdata} else
    {
      file2 <- input$file2
      ext2 <- tools::file_ext(file2$datapath)
      req(file2)
      validate(need(ext2 == "xlsx", "Please upload a .xlsx file"))

      new=  read_excel(file2$datapath, col_names  = TRUE)
      names(new)=tolower(names(new))
      new=data.frame(new)
      new=new[!is.na(new[,IDID]),]

      new$site[new$site%in%c("PBRC (1)", "PBRC", "1", 1)]=1
      new$site[new$site%in%c("KP (2)", "KP", "2", 2)]=2
      new$site[new$site%in%c("DFCI (3)", "DFCI", "3", 3)]=3

      new$sex[new$sex%in%c("Male (1)", "Male", "1", 1)]=1
      new$sex[new$sex%in%c("Female (0)", "Female", "0", 0)]=0

      new$age2=NA
      new$age2[new$age>60]=1
      new$age2[new$age<=60]=0

      new$duration[new$duration%in%c("3 months (0)", "3 months", "0", 0)]=0
      new$duration[new$duration%in%c("6 months (1)", "6 months", "1", 1)]=1

      new$oxaliplatin[new$oxaliplatin%in%c("No (0)", "No", "0", 0)]=0
      new$oxaliplatin[new$oxaliplatin%in%c("Yes (1)", "Yes", "1", 1)]=1

      new$stage[new$stage%in%c("Stage II (0)", "Stage II", "0", 0)]=0
      new$stage[new$stage%in%c("Stage III (1)", "Stage III", "1", 1)]=1

      new$chemo[new$chemo%in%c("No (0)", "No", "0", 0)]=0
      new$chemo[new$chemo%in%c("Yes (1)", "Yes", "1", 1)]=1
    }

    print(new)

    if (any(names(new)==groupID)) {} else
    {new$randomization_group=NA}
    if (any(names(datam)==groupID)) {} else
    {if (nrow(datam)>0) {datam$randomization_group=NA}}
    new=new[,c(IDID, covariates, groupID)]
    new[,IDID]=as.character(new[, IDID])

    eventcol.char=nchar(events)
    siteid=new$site
    siteid[siteid=="PBRC"]=1
    siteid[siteid=="KP"]=2
    siteid[siteid=="DFCI"]=3

    new[,eventcol]=paste0(substr(events, 1, (eventcol.char-1)), siteid)

    datam=datam[,c(IDID,eventcol, covariates, groupID)]
    datam[,IDID]=as.character(datam[,IDID])
    datam[,groupID][is.na(datam[,groupID])]=""
    datam=datam[datam[,groupID]!="",]



    wr=mr=rep(FALSE, nrow(datam))

    if (nrow(datam)>0)
    {for (i in 1:nrow(datam))
    {mr[i]=all(!is.na(datam[i,covariates]))&(datam[i,groupID]=="")
     wr[i]=any(is.na(datam[i,covariates]))&(datam[i,groupID]!="")
    }}

 # if (any(duplicates)|any(is.na(new[,IDID]))|any(new[,IDID]%in%datam[,IDID])|any(mr)|any(wr)|any(new[, IDID]=="")|
 #    any(is.na(new))|any(!new[, IDID]%in%datam0[, IDID])|any(is.na(datam[,covariates]))) {} else


    {
#    new=new[new[,IDID]%in%datam0[,IDID],]





    for (i in 1:length(covariates))
    {if  (is.factor(new[,covariates[i]])) {new[,covariates[i]]=as.character(new[,covariates[i]])}
      if  (is.factor(datam[,covariates[i]])) {datam[,covariates[i]]=as.character(datam[,covariates[i]])}
      new[is.na(new[,covariates[i]]),covariates[i]]=""
      new=new[new[,covariates[i]]!="",]
      datam[is.na(datam[,covariates[i]]),covariates[i]]=""
      datam=datam[datam[,covariates[i]]!="",]
    }

    if (nrow(datam)==0) {data=new} else
    {data=rbind(datam, new)}

    dataevent=data[, c(IDID, eventcol)]
    data=data[!duplicated(data[, IDID]),]

    covnames=names(data)
    categorical=covnames[!covnames%in%c(IDID, eventcol, groupID)]
    categorical=categorical[categorical%in%covariates]
    Continuous= Continuous
    Continuous=Continuous[Continuous%in%names(data)]
    categorical=categorical[!categorical%in%Continuous]

    if (trial=="single-site")
    {categorical=categorical[!categorical%in%c("site")]}

    data$randomization_group[is.na(data$randomization_group)]=""
    planned.sample.size= planned.sample.size

    if (trial=="multi-site")
    {  categoricalx=c(categorical[!categorical%in%c("site")])
    for (i in 1:length(categoricalx))
    {interi=as.factor(as.character(paste(data$site, data[,categoricalx[i]], sep="-")))

    if (i==1) {inx=data.frame(interi)} else {inx=data.frame(inx, interi)}
    }
    inx=as.data.frame(inx)
    names(inx)=paste0("site-",categoricalx)
    data=cbind(data,inx)

    if (length(Continuous)>0)
    {
      nsite=rep(NA, nrow(data))
      nsite[data$site=="PBRC"]=1
      nsite[data$site=="KP"]=2
      nsite[data$site=="DFCI"]=3

      for (j in 1:length(Continuous))
      {sContinuous=nsite*data[,Continuous[j]]
      if (j==1) {dContinous=sContinuous} else
      {dContinous=cbind(dContinous, sContinuous)}
      }
      dContinous=as.data.frame(dContinous)
      names(dContinous)=paste0("site-", Continuous)
      data=cbind(data, dContinous)
      Continuous=c(Continuous, names(dContinous))
    }
    categorical=names(data)[-which(names(data)%in%c(IDID, eventcol, groupID, Continuous))]
    }
    group.level=c(groupletterID)[1:(as.numeric(substr(arms,1,1)))]

        #eids=c(strsplit(input$excludedid, ",")[[1]])
    if (length(input$excludedid)==0) {eids="NO exclusion!"} else
    {excludedid <- input$excludedid
    excld2 <- tools::file_ext(excludedid$datapath)
    validate(need(excld2 == "xlsx", "Please upload a .xlsx file"))

    ex= as.data.frame(read_excel(excludedid$datapath, col_names = TRUE))
    names(ex)=IDID

    eids=ex[,IDID]}
    if (any(eids%in%data[, IDID]))
    {excluded.data=data[data[, IDID]%in%eids,]
    data=data[!data[, IDID]%in%eids,]}

    datab=data

    group.level=as.factor(group.level)
    if (length(Continuous)<1)
    {
      data$randomization_group=FUN.BCAR(data,group.var=groupID, categorical.covariates =  categorical, group.level=group.level,
                                        planned.sample.size = planned.sample.size)

    } else
    {data$randomization_group=FUN.BCAR(data,group.var=groupID, categorical.covariates =  categorical, continuous.covariates = c(Continuous), group.level=group.level,
                                       planned.sample.size = planned.sample.size)
    }

    outdata0=outdata1=outdata=data
    outdata0=outdata[,c(IDID, eventcol, covariates)]
    outdata1=outdata[,c(IDID, eventcol, groupID)]
    outdata1[, eventcol]=paste0("b", substr(outdata1[, eventcol], 4, 50))

    for (i in 1:length(covariates))
    {wh.name=which(tolower(names(outdata0))==tolower(covariates[i]))
    names(outdata0)[wh.name]=covariates[i]
    }

  #  redcap_write(outdata0,redcap_uri=api_url, token=api_token)
    redcap_write(outdata1,redcap_uri=api_url, token=api_token)

    newlyRandomized=NULL
    newlyRandomized=data[data[, IDID]%in%datab[, IDID][(is.na(datab$randomization_group))|(datab$randomization_group=="")],]

    for (i in 1:( length(categorical)))
    { data[,categorical[i]]=as.factor(data[,categorical[i]])}
    out=vector("list", 1+length(categorical))
    data$`Assigned group`=rep("n", nrow(data))
    for (i in 1:(1+length(categorical)))
    { dd=table(as.factor(data[,c("Assigned group", categorical)[i]]), factor(data$randomization_group, group.level))
    ddd= as.data.frame.matrix(dd)
    ddd$var=row.names(ddd)
    names(ddd)[names(ddd)=="var"]=c("Assigned group", categorical)[i]
    out[[i]]=ddd
    }

    if (input$display=="No")
    {out=vector("list", 1+length(categorical))}

    df_names=paste0("table", 1:(1+length(categorical)))

    for (i in 1:(1+length(categorical)))
    { local({i<-i;
    output[[df_names[i]]] = DT::renderDataTable(out[[i]], rownames=FALSE,
                                                options = list(dom = 't',bFilter=0, autoWidth = TRUE,
                                                               columnDefs = list( list(targets = as.numeric(substr(input$arms,1,1)), className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'blue';}")),
                                                                                  #list(targets = 0                                   , className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'white';}")),
                                                                                  list(orderable=FALSE, targets='_all', className = 'dt-center', visible=TRUE, width='100') ),
                                                               buttons = list(list(extend = 'copy', title = "My custom title 1")), pageLength = 15, lengthChange = FALSE,
                                                               initComplete = JS(
                                                                 "function(settings, json) {",
                                                                 "$(this.api().table().header()).css({'background-color': 'blue', 'color': 'white'});",
                                                                 "}"))
    )})}

    if (nrow(newlyRandomized)<1)
    {newlyRandomized=NULL
    NOnewlyRandomized="No new group assignment was made. Please make sure this(these) NEW subject has(ve) not been assigned to a group before runing this software."
    output$WNOnewlyRandomized=shiny::renderUI( HTML(as.character(div(style="color: red;", NOnewlyRandomized))))} else
    {
      output$WNOnewlyRandomized=shiny::renderUI( HTML(as.character(div(style="color: red;", ""))))

      output$table99=NULL
      output$table99 <- DT::renderDataTable(newlyRandomized[,c(IDID, groupID)], rownames=FALSE,
                                            options = list(dom = 't',bFilter=0,addClass = 'green-table',  autoWidth = TRUE,
                                                           columnDefs = list(# list(targets = 0                                   , className = "dt-center", createdCell = JS("function(td, cellData, rowData, row, col) {td.style.color = 'white';}")),
                                                                              list(orderable=FALSE, targets='_all', className = 'dt-center', visible=TRUE, width='90')
                                                           ),
                                                           initComplete = JS( "function(settings, json) {",  "$(this.api().table().header()).css({'background-color': 'green', 'color': 'white'});", "}"),
                                                           pageLength = 15, lengthChange = FALSE)
                                            )



      output$downloadData <- downloadHandler(
        filename = function() { paste0("Randomization data for the new subject(s).",Sys.Date(), ".csv") },
        content = function(file) {
          write.csv(newlyRandomized[,c(IDID, groupID)], file, row.names = FALSE)
        }
      )
    }

    output$downloadDataC <- downloadHandler(
      filename = function() { paste0("Randomization data for all subjects.",Sys.Date(), ".csv") },
      content = function(file) {
        write.csv(data[,c(IDID, covariates, groupID)], file, row.names = FALSE)
      }
    )
    if (eids[1]!="NO exclusion!")
    {eex=ex; names(eex)="Excluded IDs"
    output$table98 <- DT::renderDataTable(eex,
                                          options = list(dom = 't',bFilter=0,
                                                         autoWidth = TRUE,  columnDefs = list(list(orderable=FALSE,targets='_all', className = 'dt-center', visible=TRUE, width='50') ),
                                                         buttons = list(
                                                           list(extend = 'copy', title = "My custom title 1")),pageLength = 15, lengthChange = FALSE)
    )}






    }
  }
  )


}



