
#' The OR.fun function
#'
#' @param x  A predictor variable.
#'
#' @param data The data to be used.
#'
#' @param option There are three options: "Quantile" - change predictor to quantiles; "ordinal" treat quantiles as ordinal; "Raw" do not change.
#'
#' @param cutoff The cutoff value for dichotomize the outcome.
#'#'
#' @param path The folder name for write the outcome to.
#'
#' @param constant  A constant to be added to the Beta distribution to reflect the appropriate prior. For example, constant=1 reflects uniform (0,1), and constant=0.5 reflects Jeffery's prior.
#'
#' @examples
#'
#' # This is the function for doing logistic regression.
#'
#' @export


##############################
# The logistic regression analysis for a binary outcome

OR.fun=function(data, x, option, y, cutoff, path)
{data=as.data.frame(data)
  data$x=data[,x]; data$y=as.numeric(data[,y])
  data$quantiles <- cut(data$x, breaks = quantile(data$x, probs = seq(0, 1, 0.25), na.rm=TRUE), include.lowest = TRUE, labels = c("QQ1", "QQ2", "QQ3", "QQ4"))
  data$ocat <- cut(data$x, breaks = quantile(data$x, probs = seq(0, 1, 0.25), na.rm=TRUE), include.lowest = TRUE, labels = c(1,2,3,4))
  data$ocat=as.numeric(data$ocat)

  data$y2= data$y>cutoff

  ##############################################################################
  if (option%in%c("Quantile", "quantile"))

 { mdl= (glm((data$y2)~data$quantiles+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1, family="binomial"))
 mdl= (glm((data$y2)~data$quantiles+data$age10+ data$race + data$female +data$kcal1, family="binomial"))
 smdl=as.data.frame(round(summary(mdl)$coefficients,3) )
  ors=or_glm(data = data, model = mdl )
pout=round(prop.table(table(data$quantiles, data$y2), margin = 2),2)*100
fout=as.data.frame(cbind(paste0( table(data$quantiles, data$y2)[,1], "(", pout[,1], ")"),
                         paste0( table(data$quantiles, data$y2)[,2], "(", pout[,2], ")")))
rownames(fout)=rownames(table(data$quantiles, data$y2))
colnames(fout)=colnames(table(data$quantiles, data$y2))
or=ors[1:(nrow(fout)-1),]
rf=row.names(fout)
for (i in 1:nrow(or))
{
  orni=or[i,1]
  if (regexpr(rf[i+1], orni)[1]== -1) {break}
}

out=cbind(c("Q1", "Q2", "Q3", "Q4"),fout, c("reference", paste0(or[,2], "(", or[,3], ", ", or[,4], ")")), c("", round(smdl[2:nrow(fout),4],3)))
names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)", "p")
out=cbind(c("Q1", "Q2", "Q3", "Q4"),fout, c("reference", paste0(or[,2], "(", or[,3], ", ", or[,4], ")")) )
names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)" )

write.csv(out , paste(path, "Quantile.", x,".", y,".",cutoff,".csv", sep=""), row.names=FALSE)}

  ##############################################################################
  if (option%in%c("Ordinal", "ordinal"))

  {data$x=data$ocat
  mdl= (glm((data$y2)~data$x+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1, family="binomial"))
  mdl= (glm((data$y2)~data$x+data$age10+ data$race + data$female +data$kcal1, family="binomial"))
  smdl=round(summary(mdl)$coefficients,3)
  ors=or_glm(data = data, model = mdl )

  mout=round(aggregate(data$x, list(data$y2), FUN="mean", na.rm=TRUE)[,2],1)
  sdout=round(aggregate(data$x, list(data$y2), FUN="sd", na.rm=TRUE)[,2],1)
  msd=c(paste0(mout[1], "(", sdout[1], ")"),paste0(mout[2], "(", sdout[2], ")"))
  or=ors[1,]

  out=as.data.frame(cbind(paste0( "Trend"), t(c(msd, c(paste0(or[,2], "(", or[,3], ", ", or[,4], ")")), round(smdl[2,4],3)))))
  names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)", "p")
  out=as.data.frame(cbind(paste0( "Trend"), t(c(msd, c(paste0(or[,2], "(", or[,3], ", ", or[,4], ")")) ))))
  names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)" )

  write.csv(out[,1:4], paste(path, "Ordinal.", x,".", y,".",cutoff,".csv", sep=""), row.names=FALSE)}

   ##############################################################################
  if (option%in%c("Raw", "raw"))

  { mdl= (glm((data$y2)~data$x+data$age10+as.factor(data$race)+as.factor(data$female)+data$kcal1, family="binomial"))
  mdl= (glm((data$y2)~data$x+data$age10+ data$race + data$female +data$kcal1, family="binomial"))
  smdl=round(summary(mdl)$coefficients,3)
  ors=or_glm(data = data, model = mdl )

  mout=round(aggregate(data$x, list(data$y2), FUN="mean", na.rm=TRUE)[,2],1)
  sdout=round(aggregate(data$x, list(data$y2), FUN="sd", na.rm=TRUE)[,2],1)
  msd=c(paste0(mout[1], "(", sdout[1], ")"),paste0(mout[2], "(", sdout[2], ")"))
  or=ors[1,]

  out=as.data.frame(cbind(paste0( "Continuous"), t(c(msd, c(paste0(or[,2], "(", or[,3], ", ", or[,4], ")")), round(smdl[2,4],3)))))
  names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)", "p")
  out=as.data.frame(cbind(paste0( "Continuous"), t(c(msd, c(paste0(or[,2], "(", or[,3], ", ", or[,4], ")")) ))))
  names(out)=c(x, paste0(y,"<=",cutoff), paste0(y,">",cutoff), "OR(95% CI)" )

  write.csv(out, paste(path, "Continuous.", x,".", y,".",cutoff,".csv", sep=""), row.names=FALSE)}


return(out)
}
